// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DisplayAuctionsComponent } from './display-auctions.component';

// describe('DisplayAuctionsComponent', () => {
//   let component: DisplayAuctionsComponent;
//   let fixture: ComponentFixture<DisplayAuctionsComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DisplayAuctionsComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DisplayAuctionsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });

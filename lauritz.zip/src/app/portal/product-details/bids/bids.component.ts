import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bids',
  templateUrl: './bids.component.html',
  styleUrls: ['./bids.component.scss']
})
export class BidsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
